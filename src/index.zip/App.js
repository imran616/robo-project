import React, { Component } from 'react';
import Demo from './Demo';
import { robots } from './robots';
import Findbox from './Findbox';

class App extends Component {
    constructor() {
        super()
        this.state= {
            robots: 'robots',
            searchfield: ''
        }
    }

    onSearchchange = (event) => {
        this.setState({ searchfield: event.target.value })
        }
        


    render() {
        const filteredrobots = this.state.robots.filter(robots =>{
            return robots.name.tolowercase().includes(this.state.searchfield.tolowercase());
        })
    return (
        <div className='tc'>
            <h1>Robofriends</h1>
            <Findbox  Searchchange={this.onSearchchange} />
            <Demo robots={filteredrobots} />
        </div>
        );
    }
}

export default App;
